package client;

public class AppointmentMenu {
    public static void main(String[] args) {
        menu();
        int option;


    }

    public static void menu() {
        System.out.println("Appointment Management");
        System.out.println("{1} Add appointment");
        System.out.println("{2} Read appointment"); //sort
        System.out.println("{3} Search appointment");
        System.out.println("{4} Update appointment");
        System.out.println("{5} Delete appointment");

        System.out.println("Enter a option: ");
    }

}
