package entity;

import java.sql.Time;
import java.util.Date;

public class Appointment {
    //Data member

    private String ID;
    //private Patient patient;
    private Date date;
    private Time time;
    private String Remarks;
    //private Doctor doctor;
    private boolean Status;




}
